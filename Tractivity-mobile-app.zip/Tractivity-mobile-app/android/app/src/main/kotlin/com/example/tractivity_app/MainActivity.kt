package com.example.tractivity_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
