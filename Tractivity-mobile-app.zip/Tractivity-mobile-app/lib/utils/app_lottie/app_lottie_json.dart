class AppLottieJson {
  static const String basePath = "assets/lottie";


  ///=========================Nab bar Icon ======================
  static const String loading = "$basePath/loading.json";

}