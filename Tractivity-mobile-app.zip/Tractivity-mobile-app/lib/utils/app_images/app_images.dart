class AppImages {
  static const String basePath = "assets/images";

  static const String logo = "$basePath/logo.svg";


  ///====================== Onborading =========================
  static const String onboarding = "$basePath/onboardinImage.jpeg";
  static const String splashImage = "$basePath/splash_image.png";
  static const String image = "$basePath/imagei.png";
  static const String mapimage = "$basePath/mapimage.png";
  static const String confirmbooking = "$basePath/confirmbooking.png";
  static const String userImage = "$basePath/user2.png";




}
